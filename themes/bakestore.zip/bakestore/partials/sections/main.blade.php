<section id="main">
	Main Section
	<small>
		[{!! protectEmail('email@example.com') !!}]
	</small>
</section>